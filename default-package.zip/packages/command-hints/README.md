# command-hints
Provides clientside command hints for the [Command Manager](https://gitlab.nanos.io/jc3mp-packages/command-manager).