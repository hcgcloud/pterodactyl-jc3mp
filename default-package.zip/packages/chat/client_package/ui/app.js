new Vue({
	el: '#app',
	components: {
		chat: window.Chat,
	},
});